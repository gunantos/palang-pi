sudo python /home/pi/appkita/app.pyc
